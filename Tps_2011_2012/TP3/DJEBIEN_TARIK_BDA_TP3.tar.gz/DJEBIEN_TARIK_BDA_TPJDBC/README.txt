README :

// Auteur : Djebien Tarik
// Date : Octobre 2011
// UE : BDA
// Objet : TP3 application virement bancaire (TP JDBC-suite)


Arborescence de l'archive :
     |
     |___src/ les sources .java 
     |___bin/ les bytecodes .class
     |___install/init.sql : Le script de création des tables de la BDD
     |
     |___docs/ la Javadoc
     |
     |___lib/ le JAR driver Oracle ojdbc14
     |
     |___compte.jar le JAR de l'application contenant les sources et la Javadoc, celui-ci doit être dans le même dossier que /lib lors de son execution avec "$java -jar compte.jar" pour être fonctionnel.
     |
     |___README.txt ce fichier courant
     |___manifest pour le JAR executable



Cordialement,

Djebien Tarik.
